(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customBearTable', function() {
    return {
      controllerAs: 'ctrl',
      controller: /**
 * The controller is a JavaScript function that augments the AngularJS scope and exposes functions that can be used in the custom widget template
 * 
 * Custom widget properties defined on the right can be used as variables in a controller with $scope.properties
 * To use AngularJS standard services, you must declare them in the main function arguments.
 * 
 * You can leave the controller empty if you do not need it.
 */
function ($scope, $filter) {

    var ctrl=this;
    
    
    this.myListOptions = [{key:"IE",            display:"Internet"},
                {key:"CHROME",           display:"Chrome" },
                {key:"FIREFOX",          display:"Firefox" }];
    this.choosenValue_select= this.myListOptions[2];
    this.getTestListSelect = function() { 
        return this.myListOptions; };
        
    this.getTestListDisplay = function() { 
        var listDisplay=[];
        for (var i=0;i<this.myListOptions.length;i++) {
            listDisplay.push( this.myListOptions[ i ].display);
        }
        return listDisplay; 
        
    };
    this.getTestDisplay = function( item )
    {
        return item.display;
    }
	
     //---------
	// Return the InitValue
	this.getWSelectDateLongInitValue = function(header, valueDate) {
	  var dateObject = new Date( valueDate );
	  console.log( "getWSelectDateLongInitValue: valueDate["+valueDate+"] dateLong["+dateObject.getTime()+"]");
	  
	  return dateObject.toISOString().substring(0, 10);
	}
	
	//---------
	// User select a date, then calculate the new DateLong from the date
	// input : "2016-03-30T07:00:00.000Z" => Produce 1459321200000
	this.getWSelectDateLongFromDate = function(header, valueDate) {
	  var dateObject = new Date( valueDate );
	  console.log( "selectDateLongFromDate: valueDate["+valueDate+"] dateLong["+dateObject.getTime()+"]");
	  
	  return dateObject.getTime();
	}
	
	//--------- widget SELECT : for one OptionItem (ex {key:"FR", display:"France"}, according header.listoptiondisplay == "display", return "France"
	this.getWSelectDisplayFromItem = function ( header, optionItem ) {
	    if (header.control === 'select')
	    {
	        // console.log("getWSelectDisplayFromItem= "+ JSON.stringify( optionItem ));

            if (header.listoptiondisplay===null)
            {
    	        console.log(" -defaultdisplay:"+optionItem.display+")");
	            return optionItem.display;
            }
	        return optionItem[ header.listoptiondisplay ];
	    }
	    return null;
	}
	
	// --------------------------------------------------
    // ------------------ Check
    // --------------------------------------------------

    this.errorMessage="";
    this.checkRules = function() {
        console.log("~~~~~~~~~~~~~~~~~~ CheckRules");
        console.log("checkRules : value="+$scope.properties.value );
	    if (($scope.properties.value === null) || (typeof $scope.properties.value === 'undefined')) {
			console.log("~~~~~~~~~~~~~~~~~~ CheckRules: no data");
			return null;
		}
        this.errorMessage="";
        if ($scope.properties.checkrules === null) {
            console.log("~~~~~~~~~~~~~~~~~~ CheckRules:No rules defines");
            return;
        }
        for (var i=0;i<$scope.properties.checkrules.length;i++) {
            var rule = $scope.properties.checkrules[ i ];
             console.log("~~~~~~~~~~~~~~~~~~ CheckRules:rule "+rule.rule);
              
            if (rule.rule == 'sumcol') {
                var totalCol = 0;
                console.log("~~~~~~~~~~~~~~~~~~ CheckRules:SumCol");
                if (rule.totalsum === null) {
                    this.errorMessage = this.errorMessage+ "rule "+rule.name+" the properties[totalsum] is not defined;"
                }
                if (rule.colname === null) {
                    this.errorMessage = this.errorMessage+ "rule "+rule.name+" the properties[colname] is not defined;"
                }
                // now do the job
                if ($scope.properties.value === null) {
                    console.log("~~~~~~~~~~~~~~~~~~ CheckRules:NoData");
                } else {
                    for (var j=0; j<$scope.properties.value.length; j++){
    	                var oneRow = $scope.properties.value[ j ];
    	                var valueRow = oneRow[ rule.colname ];
    	                console.log("OneRow.value = "+valueRow);
    	                if (valueRow!==null) {
    	                    totalCol = totalCol + valueRow;
    	                }
                    }
                }
                console.log("compare "+totalCol+" and "+rule.totalsum);
                if (totalCol !== rule.totalsum) {
                    this.errorMessage = this.errorMessage+ rule.message+" : "+totalCol+";"
                }
            
            } else if (rule.rule == 'uniquecol') {
                 if (rule.colname === null) {
                    this.errorMessage = this.errorMessage+ "rule "+rule.name+" the properties[colname] is not defined;"
                }
                // now do the job
                if ($scope.properties.value === null) {
                    console.log("~~~~~~~~~~~~~~~~~~ CheckRules:NoData");
                } else {
                    var message="";
                    for (var j2=0; j2<$scope.properties.value.length; j2++){
    	                var oneRow2 = $scope.properties.value[ j2 ];
    	                var valueRow2 = oneRow2[ rule.colname ];
    	                // console.log("OneRow.value = "+valueRow);
    	                for (var k=j2+1; k<$scope.properties.value.length; k++){
    	                    var oneNextRow = $scope.properties.value[ k ];
    	                    var valueNextRow = oneNextRow[ rule.colname ];
                            if (valueRow2 === valueNextRow) {
                                message = message +" : line "+(j+1)+"["+valueRow2+"] and "+(k+1)+"["+valueNextRow+"];"
                            }
    	                }
                    }
                    if (message!=="") {
                        this.errorMessage = this.errorMessage+ rule.message+" "+message+" are identical";
                    }
                }
            }
            else {
              this.errorMessage = this.errorMessage+ "Unknow rule ["+rule.rule+"];";
            }
        }
        console.log("~~~~~~~~~~~~~~~~~~~ Rule message: "+this.errorMessage);
    }
    
    this.getErrorMessage = function () {
         console.log("Get Error message: "+this.errorMessage);
        return this.errorMessage;
    }
    
    
  
        
    // add a new variable in AngularJS scope. It'll be usable in the template directly with {{ backgroundColor }} 
    this.filterrecord={};
    this.reverseSort=false;
    this.orderByField="";
    // this then the HTML can directly modify this value
    this.recordpagenumber=1;
	this.recorditemsperpage= 1000;
	
	// --------------------------------------------------
    //------------------ Action rules
    // --------------------------------------------------
    this.defaultSort = function () 
    {
        console.log("--------------- DefaultSort?");
        if ($scope.properties.actionsRules !== null)
        {
            for (var i=0;i<$scope.properties.actionsRules.length;i++) {
                var actionRule = $scope.properties.actionsRules[ i ];
                console.log("--------------- Sort:actionrule.action="+actionRule.action);
                if (actionRule.action === 'sort') {
                    
                    console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>> Sort ! ");
                     $scope.properties.value.sort( function(a, b){
                         if (typeof actionRule.sort1 === 'undefined')
                            return 0;
                         var valueA = a[ actionRule.sort1 ];
                         var valueB = b[ actionRule.sort1 ];
                         console.log(" -- sort on["+ actionRule.sort1+"] a["+JSON.stringify(a)+"] b["+JSON.stringify(b)+"]");
                        
                         console.log(" -- sort type["+( typeof valueA )+"] valueA["+valueA+"] valueB["+valueB+"]");
                         if (valueA < valueB)
                            return -1;
                         if (valueA > valueB)
                            return 1;
                        // egals : check sort2
                         var valueA2 = a[ actionRule.sort2 ];
                         var valueB2 = b[ actionRule.sort2 ];
                         if (valueA2 < valueB2)
                            return -1;
                         if (valueA2 > valueB2)
                            return 1;
                        return 0;
                     } );
                }
            }
        }
    }
    this.defaultSort();
    
    // style on header
    this.getStyleHeader= function (header) {
	    if (typeof header.styleheader !== 'undefined') {
            return header.styleheader ;
        }
		return "";
	}
	
    // ActionStyle
    this.getActionStyleCell = function( header, oneRecord )
    {
        // console.log("--------------- getActionStyleCell ["+header.name+"]");
        if ($scope.properties.actionsRules !== null)
        {
            for (var i=0;i<$scope.properties.actionsRules.length;i++) {
                var actionRule = $scope.properties.actionsRules[ i ];
                // console.log("--------------- getActionStyleCell:actionrule.action="+actionRule.action);
                if (actionRule.action === 'styleline') {
                    if (this.actionApply("Style", actionRule, oneRecord))
                    {
                       // console.log("--------------- getActionStyleCell:actionRule Styleline TRUE return ["+actionRule.style+"]");
                       return actionRule.style;
                    }
                }
            }
        }
  

       var attrName = header.name + "_style";
        // console.log("--------------- getActionStyleCell: by attrName ["+ attrName + "]" );
        if ((typeof oneRecord[ attrName ] !== 'undefined') && ( oneRecord[ attrName ] !== null)) {
            return oneRecord[ attrName ];
        }
        
        // console.log("--------------- getActionStyleCell: by styleCol" );
        if ((typeof header.stylecol != 'undefined') && (header.stylecol !== null)) {
            return header.stylecol;
        }

     
        return "";
    }
    
    // ------------- P1 T getActionReadOnly
    this.getActionReadOnly = function(header, oneRecord )
    {
       if ((typeof oneRecord === 'undefined'))
       {
          // console.log("-----------getActionReadOnly:["+header.name+"] :oneRecord undefined  HeaderReadOnly ["+header.readonly+"]");
          return header.readonly; 
       }
        var readOnlyAttribut = oneRecord[ header.name+'_readonly' ];
        // console.log("----------- getActionReadOnly: ["+header.name+"] : ReadOnly ["+header.readonly+"] readOnlyAttribut ["+readOnlyAttribut+"]")
        if ((typeof readOnlyAttribut != 'undefined') && (readOnlyAttribut !== null)) {
            return readOnlyAttribut;
        }
       
        // console.log("-----------getActionReadOnly:actionRules=["+$scope.properties.actionsRules+"]");
                
        if ($scope.properties.actionsRules !== null)
        {
            for (var i=0;i<$scope.properties.actionsRules.length;i++) {
                var actionRule = $scope.properties.actionsRules[ i ];
                if (actionRule.action === 'readonlyline') {
                    //console.log("--------------- getReadOnly:["+header.name+"] :actionrule.action="+actionRule.action);
                    if (this.actionApply( "ReadOnly", actionRule, oneRecord))
                    {
                       //console.log("--------------- getReadOnly:["+header.name+"]: ActionRule return [true]");
                       return true;
                    }
                }
            }
        }
        
        // less priority : the header
         if ((typeof header.readonly != 'undefined') && (header.readonly !== null)) {
            return header.readonly;
        }
        return false;
    }
    
    // HideLine
    this.getActionHideLine = function( oneRecord )
    {
        //console.log("--------------- getActionHideLine: by record "+JSON.stringify( oneRecord ) );
        if ($scope.properties.actionsRules !== null)
        {
            for (var i=0;i<$scope.properties.actionsRules.length;i++) {
                var actionRule = $scope.properties.actionsRules[ i ];
                // console.log("---------------  actionRule.action="+actionrule.action);
                if (actionRule.action === 'hideline') {
                    // console.log("--------------- getActionHideLine::actionrule.name="+actionRule.name);
                    if (this.actionApply( "HideLine", actionRule, oneRecord))
                    {
                       // console.log("--------------- getActionHideLine: ActionRule return [true]");
                       return true;
                    }
                }
            }
        }
        return false;
    }
    
    // private: check if the rule apply to this record
    this.actionApply= function( source, actionRule, oneRecord) {
         // console.log("--------------- getStyle:actionRule Styleline attribut["+ actionRule.attribut+"]");
        
        var resultAttribut = true;
        var resultVariable = true;
        var valueAttribute = null;
        var valueVariable = null;
        
        if ((typeof  actionRule.attribut != 'undefined') && actionRule.attribut !== null) {
            valueAttribut = oneRecord[ actionRule.attribut ];
            if ((typeof valueAttribut != 'undefined') && (valueAttribut === actionRule.valueattribut ))
                resultAttribut= true;
            else
                resultAttribut=false;
        }
        // by the variable
        if ((typeof  actionRule.variable != 'undefined') &&  actionRule.variable !== null) {

            valueVariable = $scope.properties.dynamicLists[ actionRule.variable ];
            // console.log("--------------- actionApply["+source+"] By Variable["+ actionRule.variable +"] (["+actionRule.valuevariable+"])=["+valueVariable+"] ? "+resultVariable);
            if ((typeof valueVariable != 'undefined') && (valueVariable === actionRule.valuevariable ))
                resultVariable= true;
            else 
                resultVariable = false; 
        }
        
        // console.log("--------------- actionApply["+source+"] Attribut["+ actionRule.attribut+"] (["+actionRule.valueattribut+"]) ==["+valueAttribut+"] ? "+resultAttribut + " Variable["+ actionRule.variable+"] (["+actionRule.valuevariable+"])=["+valueVariable+"] ? "+resultVariable);

        if (resultAttribut && resultVariable)
            return true;
        else
            return false;
    };
    
  
	// ------------------- control
	
	
	// widget SELECT : return the list of option for the header. Return a list like [{key:"IE", display:"Internet"},{key:"CHROME",display:"Chrome" },{key:"FIREFOX", display:"Firefox" }]
	//   Note at this moment, we don't know which attribut is the DISPLAY and which is the KEY
	this.getWSelectListOptionsItem = function( header )
	{
	    // console.log("getWSelectListOptionsItem: header["+header.name+"] control["+header.control+"]");
    	   
	    if (header.control ==='select')
	    {
    	    // console.log('getWSelectListOptionsItem: based on listoption/header='+ JSON.stringify(header));
    	    if ((typeof header.listoptions != 'undefined') && header.listoptions !== null) {
    	        // console.log('getWSelectListOptionsItem: return STATIC  listOptions='+ JSON.stringify(header.listoptions));
    	        return header.listoptions;
    	    }
    	    if ((typeof header.listoptionsvariable != 'undefined') &&  header.listoptionsvariable !== null) {
    	        // console.log("getWSelectListOptionsItem: return DYNAMIC listoptionsvariable["+ header.listoptionsvariable+"]");
    	        var value = $scope.properties.dynamicLists[ header.listoptionsvariable ];
    	        // console.log("getWSelectListOptionsItem:return DYNAMIC listoptionsvariable["+ header.listoptionsvariable+"] listOptions= "+ JSON.stringify(value ));
    	        return value;
    	    }
            // console.log("getWSelectListOptionsItem: return NO LIST");
    	    this.errorMessage = this.errorMessage + header.name+": no option defined in the list use [listoptions] or [listoptionsvariable] properties;";
	    }
	    return null;
	};
	
	// Widget Select : get the select optionItem. Record is 
	// [ browser:"FR", pid:334] and header = {name:browser, listoptionkey:"key", listoption: [{key:"GR", display:"Germany"}, {key:"FR", display:"France"}]}
	// then the function return the optionItem {key:"FR", display:"France"}
	this.getWSelectGetSelected = function(  header, record ) {
	     if (header.control ==='select') {
    	    var listOptionsItem = this.getWSelectListOptionsItem( header );
    	    // console.log("getWSelectGetSelected: ******* name["+header.name+"] listOptions="+JSON.stringify(listOptionsItem)+" record="+JSON.stringify( record )+";");
    	    if (listOptionsItem === null)
    	        return null;
    	    
    	    var valueInRecord = record[ header.name ];
    	    // console.log("getWSelectGetSelected:  InitSelect ["+header.name+"] : valueInRecord["+valueInRecord+"]");

    	    for (var i=0;i<listOptionsItem.length;i++) { 
    	        var optionRange = listOptionsItem[ i ];
    	        // console.log( "getWSelectGetSelected X"+JSON.stringify(optionRange) );
    	        var keyRange = this.getWSelectItemToKey( header, optionRange );
        	    // console.log( "getWSelectGetSelected KeyRange=["+keyRange+"];" );

    	        if (keyRange === valueInRecord ) {
            	    // console.log( "getWSelectGetSelectedReturnRange=["+i+"] : ["+JSON.stringify(listOptionsItem[ i ])+"];" );
    	            return listOptionsItem[ i ];
    	        }
    	    };
    	    // console.log("getWSelectGetSelectedInitSelect ["+header.name+"] : ** DefaultValueNotFound ** defaultValue["+defaultValue+"] listOptions=["+ JSON.stringify(listOptions )+"]");
	     }
    	 return null;
    	    
	}
	
	
	this.getListSelect = function() { return null };
	
	// widget SELECT : return the VALUE of the key of the list. Example : itemOption={ "country":"France", "PIB":"445"} / header.listoptionkey="country" => return "France"
	this.getWSelectItemToKey = function ( header, itemOption ) {
	        // this.errorMessage = this.errorMessage+" (getListKey";
	        // console.log('getListKey= '+ JSON.stringify( itemOption ));
	        if (header.listoptionkey===null) {
    	        // console.log(" -defaultkey:"+record.key+")");
	            return record.key;
	        }
	        // console.log(" -indirect("+header.listoptionkey+") : "+itemOption[ header.listoptionkey ]+")");

	        return itemOption[ header.listoptionkey ];
	}
	
	// --- pie data
	this.getListPieData = function (header ) {
	    var data = [ 12, 40, 66 ];
	     console.log('getListPieData='+JSON.stringify(data) );
	    return data;
	}
	this.getListPieHeader = function (header ) {
	    var header = [ "France","Germany","USA" ];
	    console.log('getListPieData='+JSON.stringify(header) );
	    return header;
	}

	
	
    // --------------------------------------------------
    // ------------------ Prepare Data
    // --------------------------------------------------
	this.prepareData = function() {

	    var j;
	    var oneRecord;
	    if (typeof $scope.properties.headervalue === 'undefined') {
	        console.log( "prepareData/timeLong: headervalue is undefined");
	        return false;
	    }
	    console.log("PrepareData : value="+$scope.properties.value );
	    if (($scope.properties.value === null) || (typeof $scope.properties.value === 'undefined')) {
            console.log("~~~~~~~~~~~~~~~~~~ prepareData:NoData");
            return false;
	     }
	    
	    console.log("~~~~~~~~~~~~~~~~~~PrepareData : value.length="+$scope.properties.value.length );
        
	    for (var i=0; i<$scope.properties.headervalue.length; i++){

	        var oneHeader = $scope.properties.headervalue[ i ];

			if (oneHeader.control == 'datelong') {

				 for (j=0; j<$scope.properties.value.length; j++){
    	            oneRecord = $scope.properties.value[ j ];
					var timeRow = oneRecord[ oneHeader.name ];
					console.log( "prepareData/timeLong_1: timeRow["+timeRow+"]");
	  				// date is a Time, need to change it in a Date String format
					var date = new Date(timeRow);
					// when the input are in ReadOnly, the value on '_date' is not working, and the init value must be different
					// than the init value ( ! ). In Read, Write, ng-model and value can be the same, or differrent
					// so, to avoid that, on the datelong field, a method getWSelectDateLongInitValue is called.
					oneRecord[ oneHeader.name+'_date' ] = date.toISOString().substring(0, 10);
				}
			}
			if (oneHeader.control == 'select') {
			    console.log("manager headerControlSelect");
			    
				 for (j=0; j<$scope.properties.value.length; j++){
    	                oneRecord = $scope.properties.value[ j ];
						var selected = this.getWSelectGetSelected( oneHeader, oneRecord );
						oneRecord[ oneHeader.name+'_select' ] = selected;
						console.log( "prepareData/select: value["+selected+"]");
				}
			}
			
		} // end for header
		return true;
	} // end of prepareData
	
	
	
    // ------------------- debug 
	this.isShowDebug = function() {
	    return $scope.properties.showdebug;
	}
	this.getContent = function () {
	    return $scope.properties.value;
	}
	// ------------------- pagination 
	this.isShowPagination = function() {
	    return $scope.properties.showPagination !==null && $scope.properties.showPagination.length>0;
	}
	
    this.getStepPagination = function() {
        return $scope.properties.showPagination;
    }

	this.getRecordsNumber = function() {
	    if (($scope.properties.value === null) || (typeof $scope.properties.value === 'undefined')) {
            return 0;
	    }
	    return $scope.properties.value.length;
	}
	
	this.getRecordsFilterNumber = function() {
	    // console.log("************ filterRecordNumber = "+this.listrecordsfiltered.length);
	    return this.listrecordsfiltered.length;
	}
	this.getRecordsItemPerPage = function() {
	    // console.log("************ getRecordItemPerPage = "+this.recorditemsperpage);
	    if (this.recorditemsperpage == null)
	      return 100;
	    return this.recorditemsperpage;
	}
	
    this.getRecordsPage = function()
	{
	    if (($scope.properties.value === null) || (typeof $scope.properties.value === 'undefined')) {
            return null;
	    }
	    console.log("getRecordsPage : ="+ $scope.properties.value);
		// console.log("getRecordsPage : ="+ angular.toJson($scope.properties.value,true));
	    //console.log("getRecordsPage : Orderby:"+this.orderByField+" - direction : "+this.reverseSort);
	    var listOrdered = [];
	    for (var i=0; i<$scope.properties.value.length; i++){
	        var oneRow = $scope.properties.value[ i ];
	        if (oneRow == null)
	            $scope.properties.value[ i ] = {};
	            
	        listOrdered.push( oneRow );
	    }

		listOrdered = $filter('orderBy')($scope.properties.value, this.orderByField, this.reverseSort);
		$scope.properties.value = listOrdered;
		
	    //console.log("Result After Order="+ angular.toJson(listOrdered  , true));
	    //console.log("filter : ="+ angular.toJson(this.filterrecord , true));
	    
		this.listrecordsfiltered = $filter('filter') (listOrdered, this.filterrecord );
		
		if (this.listrecordsfiltered===null)
		  return null;

		//console.log(' listcasesfiltered='+angular.toJson(this.listrecordsfiltered));
	    if (this.isShowPagination() )
	    {
		    var begin = ((this.recordpagenumber - 1) * this.recorditemsperpage);
		    var end = begin + this.recorditemsperpage;
	        // console.log("Result After Filter begin/end="+begin+"/"+end+":"+ angular.toJson(this.listrecordsfiltered , true));
    		return this.listrecordsfiltered.slice(begin, end);
	    }
		return this.listrecordsfiltered;
	    
	}
	
   
	//-------------------------- getter
	this.getHeader = function() {
	    return $scope.properties.headervalue;
	}
	this.getCheckRule = function() {
	    return $scope.properties.checkrules;
	}
	this.getOrderByField = function() {
	    return this.orderByField;
	}
	
	this.isReverseSort = function() {
	    return this.reverseSort;
	}
	
	this.getTableCss = function () {
	    return $scope.properties.tablecssclass;
	}
	
	this.getStyleCss = function () {
	    return $scope.properties.tablecssstyle;
	}
	// --  setter
	this.setOrder= function( paramorderfield, paramreversesort)
	{	
		this.orderByField = paramorderfield;
		this.reverseSort = paramreversesort;
		// console.log("SET Order : ["+this.orderByField+"] order="+this.reverseSort);		
	}
	
	
    //------------------- init
    ctrl.diseablePrepareData =false;
    
    $scope.$watch('properties.value', function(newValue, oldValue) {
        if (! ctrl.diseablePrepareData)
        {
            var prepareDataDone = ctrl.prepareData();
            ctrl.checkRules();    
            ctrl.diseablePrepareData =prepareDataDone;
        }
    }, true);
    

  
},
      template: '<!-- The custom widget template is defined here\n   - You can use standard HTML tags and AngularJS built-in directives, scope and interpolation system\n   - Custom widget properties defined on the right can be used as variables in a templates with properties.newProperty\n   - Functions exposed in the controller can be used with ctrl.newFunction()\n -->\n\n<div ng-show="environment.editor.pageId!=null">BearTable {{properties.Label}}</div>\n<table class="{{ctrl.getTableCss()}}" syle="{{ctrl.getStyleCss()}}">					\n    <tr>\n	    <th ng-repeat="header in ctrl.getHeader() track by $index" style="{{ctrl.getStyleHeader( header );}}">\n	        {{header.title}}\n	            <a ng-show="header.order == true" href="#" ng-click="ctrl.setOrder( header.name, ! ctrl.isReverseSort());" style="text-decoration:none">\n					<span ng-show="ctrl.getOrderByField() != header.name" class="glyphicon glyphicon-chevron-minus">-</span>\n					<span ng-show="ctrl.getOrderByField() === header.name && ctrl.isReverseSort()" class="glyphicon glyphicon-chevron-down"></span>\n					<span ng-show="ctrl.getOrderByField() === header.name && ! ctrl.isReverseSort() " class="glyphicon glyphicon-chevron-up"></span>\n				</a>\n		    <div ng-show="header.filter==true" >\n			    <br>\n			    <input type="text" ng-model="ctrl.filterrecord[header.name]" size="15" \n			    class="form-control filter-control"\n				title="Filter: only lines which contains this value are shown"/>\n		    </div>\n	    </th>\n    </tr>\n    <tbody  ng-repeat="oneRecord in ctrl.getRecordsPage() track by $index">\n	<tr 	ng-show="! ctrl.getActionHideLine( oneRecord)" >\n	   	<td ng-repeat="header in ctrl.getHeader() track by $index" style="{{ctrl.getActionStyleCell(header, oneRecord)}}">\n		    <div ng-show="header.control === \'link\'">\n		        <a href="oneRecord[ header.name ]">{{header.title}}</a>\n		    </div>\n		    <div ng-show="header.control === \'button\'">\n		        <button ng-click="oneRecord[ header.name ]">Click</button>\n		    </div>\n		    \n			<div ng-show="header.control === \'select\'">\n			    <!-- ng-init="oneRecord[ header.name + \'_select\'] = ctrl.getWSelectGetSelected(header, oneRecord )" -->\n		    	<select ng-model="oneRecord[  header.name+\'_select\' ]" \n			            ng-options="ctrl.getWSelectDisplayFromItem(header, item) for item in ctrl.getWSelectListOptionsItem(header)"\n			            ng-change="oneRecord[ header.name ]= ctrl.getWSelectItemToKey(header, oneRecord[ header.name+\'_select\' ]);ctrl.checkRules()"\n			            ng-disabled="ctrl.getActionReadOnly(header, oneRecord );"\n			            style="display:block;width=100%;height:26px;"\n			            >\n		    	</select>\n		    </div>\n			<div ng-show="header.control === \'input\'">\n		    	<input ng-model="oneRecord[ header.name ]" size="{{header.size}}"  ng-change="ctrl.checkRules()"\n		    	ng-disabled="ctrl.getActionReadOnly(header, oneRecord);"/>\n		    </div>\n			<div ng-show="header.control === \'text\'">\n		    	{{oneRecord[  header.name ] }}\n		    </div>\n		    <div ng-show="header.control === \'number\'">\n		    	<input ng-model="oneRecord[  header.name ]" style="width: {{header.size}}px" type="number" ng-change="ctrl.checkRules()"\n		    	 ng-disabled="ctrl.getActionReadOnly(header, oneRecord);"/>\n		    </div>\n		    <div ng-show="header.control === \'password\'">\n		    	<input ng-model="oneRecord[  header.name ]" size="{{header.size}}" type="password"\n		    	 ng-disabled="ctrl.getActionReadOnly(header, oneRecord);"/>\n		    </div>\n            	<div ng-show="header.control === \'email\'">\n		    	<input ng-model="oneRecord[  header.name ]" size="{{header.size}}" type="email"  ng-change="ctrl.checkRules()"\n		    	 ng-disabled="ctrl.getActionReadOnly(header, oneRecord);"/>\n		    </div>\n            <div ng-show="header.control === \'date\'">\n		    	<input ng-model="oneRecord[ header.name ]" size="{{header.size}}" type="date" \n		    	 ng-disabled="ctrl.getActionReadOnly(header, oneRecord);"/>\n		    </div>\n		     <div ng-show="header.control === \'datelong\'">\n		    	<input ng-model="oneRecord[ header.name +\'_date\' ]" size="{{header.size}}" type="date" \n		    	      value="{{ctrl.getWSelectDateLongInitValue(header, oneRecord[ header.name ])}}"\n		    	      ng-change="oneRecord[ header.name ]= ctrl.getWSelectDateLongFromDate(header, oneRecord[ header.name+\'_date\' ]);ctrl.checkRules()"\n			          ng-disabled="ctrl.getActionReadOnly(header, oneRecord);"/>\n		    </div>\n		     <div ng-show="header.control === \'datetime\'">\n		    	<input ng-model="oneRecord[  header.name ]" size="{{header.size}}" type="datetime"\n		    	 ng-disabled="ctrl.getActionReadOnly(header, oneRecord);"/>\n		    </div>\n		     <div ng-show="header.control === \'time\'">\n		    	<input ng-model="oneRecord[  header.name ]" size="{{header.size}}" type="time"\n		    	 ng-disabled="ctrl.getActionReadOnly(header, oneRecord);"/>\n		    </div>\n		     <div ng-show="header.control === \'hour\'">\n		    	<input ng-model="oneRecord[  header.name ]" size="{{header.size}}" type="hour"\n		    	 ng-disabled="ctrl.getActionReadOnly(header, oneRecord);"/>\n		    </div>\n		\n		    <div ng-show="header.control === \'contentjson\'">\n		    	{{oneRecord}}\n		    </div>\n		    <div ng-show="header.control === \'piechart\'">\n		        <canvas id="pie" class="chart chart-pie" chart-data="ctrl.getListPieData( header )" chart-labels="ctrl.getListPieHeader( header )" legend="true"></canvas>\n		        Pie-Data {{ctrl.getListPieData( header )}} Pie-label:{{ctrl.getListPieHeader( header )}}\n		    </div>\n		</td>		\n		\n	    <!-- <td>Control={{ctrl.getHeader()}}<br>OneRecord={{onerecord}}</td> -->\n					\n	</tr>		\n	</tbody>\n</table>\n\n<span class="label label-danger">{{ctrl.getErrorMessage()}}</span>\n\n<!-- Total number : {{ctrl.getRecordsNumber()}} / {{ctrl.getRecordsFilterNumber()}} -->\n\n<div ng-show="ctrl.isShowDebug()">\n    Debug Content:{{ctrl.getContent()}}\n</div>\n<div ng-show="ctrl.isShowPagination()">\n\n	    \n		<select ng-model="ctrl.recorditemsperpage" ng-show="false" >\n		    <option ng-repeat="item in ctrl.getStepPagination()" value="{{item.value}}">{{item.name}}</option>\n		</select>\n		\n		<!-- PageNumber={{ctrl.recordpagenumber}} total-items={{ctrl.getRecordsFilterNumber()}} item/page {{ctrl.getRecordsItemPerPage()}} -->\n		<!-- we should branch getRecordsFilterNumber() but it\'s not working... -->\n		<pagination ng-show="false" ng-model="ctrl.recordpagenumber" total-items="ctrl.getRecordsNumber()" items-per-page="ctrl.recorditemsperpage">\n		</pagination>\n</div>\n\n\n\n	'
    };
  });
